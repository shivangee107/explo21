# exploratory_project_STLF
PROJECT:-SHORT TERM LOAD FORECASTING(With Deep Residual Networks)

Submitted to: Prof. AMRITANSHU PANDEY (department of electronics engineering)

Submitted by:- SANIKA JAIN-roll no.-19095086 : SHIVANGEE PANDEY-roll no.-19095088
